// Function to handle adding a customer
document.getElementById('addCustomerForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form from submitting the usual way

    // Get form values
    const customerName = document.getElementById('customerName').value;
    const customerData = document.getElementById('customerData').value;
    const campaignName = document.getElementById('campaignName').value;

    // Create customer object
    const customer = {
        name: customerName,
        data: customerData,
        campaign: campaignName
    };

    // Send POST request to backend
    fetch('http://localhost:5000/add_customer', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(customer)
    })
    .then(response => response.json())
    .then(data => {
        alert('Customer added successfully!');
        console.log('Customer added:', data);
    })
    .catch(error => {
        alert('Error adding customer!');
        console.error('Error:', error);
    });
});

// Function to fetch and display campaign predictions
document.getElementById('fetchCampaignsBtn').addEventListener('click', function() {
    fetch('http://localhost:5000/campaigns')
    .then(response => response.json())
    .then(campaigns => {
        const tableBody = document.querySelector('#campaignsTable tbody');
        tableBody.innerHTML = ''; // Clear previous data

        // Iterate through the campaigns and append them to the table
        campaigns.forEach(campaign => {
            const row = document.createElement('tr');

            const customerIdCell = document.createElement('td');
            customerIdCell.textContent = campaign.customer_id;

            const predictionCell = document.createElement('td');
            predictionCell.textContent = campaign.prediction;

            const campaignNameCell = document.createElement('td');
            campaignNameCell.textContent = campaign.campaign;

            row.appendChild(customerIdCell);
            row.appendChild(predictionCell);
            row.appendChild(campaignNameCell);

            tableBody.appendChild(row);
        });
    })
    .catch(error => {
        alert('Error fetching campaigns!');
        console.error('Error:', error);
    });
});
