import pickle

# Load your pre-trained model (ensure it's saved as a .pkl file)
def load_model():
    with open('final_optimized_random_forest_model.pkl', 'rb') as f:
        model = pickle.load(f)
    return model

def predict_campaign_success(customer_data):
    model = load_model()
    prediction = model.predict([customer_data])
    return prediction[0]
