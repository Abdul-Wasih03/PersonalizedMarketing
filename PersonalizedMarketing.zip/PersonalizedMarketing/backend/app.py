from flask import Flask, request, jsonify
from db_config import get_db
from model import predict_campaign_success
from bson import ObjectId

app = Flask(__name__)

# MongoDB instance
db = get_db()
customers_collection = db['customers']
campaigns_collection = db['campaigns']

# Helper function to convert MongoDB documents to JSON serializable format
def serialize_campaign(campaign):
    return {
        'customer_id': str(campaign['customer_id']),
        'prediction': campaign['prediction'],
        'campaign': campaign['campaign']
    }

# Route to add customer data
@app.route('/add_customer', methods=['POST'])
def add_customer():
    customer_data = request.json
    if not customer_data:
        return jsonify({'error': 'Invalid data'}), 400

    customers_collection.insert_one(customer_data)
    return jsonify({'msg': 'Customer added successfully'}), 201

# Route to predict campaign success for a customer
@app.route('/predict_campaign', methods=['POST'])
def predict_campaign():
    customer_id = request.json.get('customer_id')

    if not customer_id:
        return jsonify({'error': 'Customer ID is required'}), 400

    customer = customers_collection.find_one({'_id': ObjectId(customer_id)})

    if customer:
        # Simulate prediction model
        prediction = predict_campaign_success(customer['data'])

        # Store the prediction in the campaigns collection
        campaigns_collection.insert_one({
            'customer_id': ObjectId(customer_id),
            'prediction': prediction,
            'campaign': customer.get('campaign', 'Unknown Campaign')
        })
        return jsonify({'prediction': prediction}), 200
    else:
        return jsonify({'error': 'Customer not found'}), 404

# Route to fetch all campaign predictions
@app.route('/campaigns', methods=['GET'])
def get_campaigns():
    campaigns = campaigns_collection.find()
    serialized_campaigns = [serialize_campaign(campaign) for campaign in campaigns]
    return jsonify(serialized_campaigns), 200

# Test route to fetch all campaigns and print in console (for debugging)
@app.route('/test_campaigns', methods=['GET'])
def test_campaigns():
    campaigns = list(campaigns_collection.find())
    for campaign in campaigns:
        print(campaign)
    return jsonify([serialize_campaign(campaign) for campaign in campaigns]), 200

if __name__ == '__main__':
    app.run(debug=True)
