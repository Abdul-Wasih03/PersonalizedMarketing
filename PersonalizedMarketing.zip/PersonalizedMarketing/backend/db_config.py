from pymongo import MongoClient

def get_db():
    client = MongoClient("mongodb://localhost:27017/")  # replace with MongoDB Atlas URI if needed
    db = client['campaign_db']  # Name of your database
    return db
